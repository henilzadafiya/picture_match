class data_class{
 static List title_name = ["Match 2","Match 3","MIRROR","MIRROR 3","Match 4","MIRROR 4"];
 static List second_count = [30,40,50,60,70,80];
}