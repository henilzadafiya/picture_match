import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:picture_match/game_paly.dart';
import 'home.dart';

void main() {
  runApp(MaterialApp(
    home: home(),
    debugShowCheckedModeBanner: false,
  ));
}
